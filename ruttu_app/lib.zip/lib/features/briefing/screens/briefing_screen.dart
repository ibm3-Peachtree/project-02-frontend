import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../../core/theme/app_colors.dart';
import '../../../data/models/weather_model.dart';
import '../../../data/models/route_model.dart';
import '../../../data/repositories/briefing_repository.dart';
import '../providers/briefing_provider.dart';

class BriefingScreen extends ConsumerStatefulWidget {
  const BriefingScreen({super.key});

  @override
  ConsumerState<BriefingScreen> createState() => _BriefingScreenState();
}

class _BriefingScreenState extends ConsumerState<BriefingScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(briefingProvider.notifier).load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(briefingProvider);
    final now = DateTime.now();
    final dateLabel = DateFormat('M월 d일 EEEE', 'ko').format(now);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        centerTitle: true,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Text(
              '오늘의 브리핑',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
            ),
            Text(
              dateLabel,
              style: const TextStyle(
                fontSize: 13,
                color: AppColors.textSecondary,
                fontWeight: FontWeight.normal,
              ),
            ),
          ],
        ),
        toolbarHeight: 64,
      ),
      body: state.isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: EdgeInsets.fromLTRB(
                16,
                8,
                16,
                32 + MediaQuery.of(context).padding.bottom,
              ),
              children: [
                // ① AI 요약 카드
                _AiSummaryCard(summary: state.aiSummary),
                const SizedBox(height: 12),

                // ② 교통 이슈 카드
                _TrafficIssueCard(issues: state.issues),
                const SizedBox(height: 12),

                // ③ 날씨 카드
                if (state.briefingWeather != null)
                  _BriefingWeatherCard(weather: state.briefingWeather!)
                else if (state.weather != null)
                  _WeatherCard(weather: state.weather!),
                const SizedBox(height: 12),
                // ④ 준비물 브리핑 카드
                if (state.briefingWeather != null)
                  _BriefingPrepCard(weather: state.briefingWeather!)
                else if (state.weather != null)
                  _PrepCard(weather: state.weather!),
                const SizedBox(height: 12),

                // ⑤ 오늘의 일정 카드 (Google Calendar)
                _ScheduleCard(
                  calendarGroups: state.calendarGroups,
                  calendarError: state.calendarError,
                ),
                const SizedBox(height: 12),

                // ⑥ 미팅 경로 카드
                if (state.meetingRoute != null)
                  _MeetingRouteCard(route: state.meetingRoute!),
                if (state.meetingRoute != null) const SizedBox(height: 12),
              ],
            ),
    );
  }
}

// ── ⑦ 새 날씨 카드 (ResponseWeatherDto 기반) ───────────────────────────────
class _BriefingWeatherCard extends StatelessWidget {
  final BriefingWeatherModel weather;
  const _BriefingWeatherCard({required this.weather});

  String get _skyEmoji {
    switch (weather.sky) {
      case '맑음': return '☀️';
      case '구름 많음': return '⛅';
      case '흐림': return '☁️';
      default: return '🌤';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.wb_sunny_outlined, color: AppColors.primary),
                const SizedBox(width: 8),
                const Text('오늘의 날씨',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(_skyEmoji, style: const TextStyle(fontSize: 40)),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${weather.tmp.toStringAsFixed(1)}°',
                        style: const TextStyle(
                            fontSize: 32, fontWeight: FontWeight.w700)),
                    Text('${weather.sky}  ${weather.pcp}',
                        style: const TextStyle(
                            fontSize: 13, color: AppColors.textSecondary)),
                  ],
                ),
                const Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text('최고 ${weather.maxTemp.toStringAsFixed(0)}°',
                        style: const TextStyle(
                            fontSize: 13, color: Colors.red)),
                    Text('최저 ${weather.minTemp.toStringAsFixed(0)}°',
                        style: const TextStyle(
                            fontSize: 13, color: Colors.blue)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Divider(),
            const SizedBox(height: 8),
            Row(
              children: [
                _AirBadge(label: 'PM10', value: weather.pm10),
                const SizedBox(width: 8),
                _AirBadge(label: 'PM2.5', value: weather.pm25),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _AirBadge extends StatelessWidget {
  final String label;
  final String value;
  const _AirBadge({required this.label, required this.value});

  Color get _color {
    switch (value) {
      case '좋음': return Colors.blue;
      case '보통': return Colors.green;
      case '나쁨': return Colors.orange;
      case '매우나쁨': return Colors.red;
      default: return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: _color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _color.withValues(alpha: 0.4)),
      ),
      child: Text(
        '$label $value',
        style: TextStyle(
            fontSize: 12, color: _color, fontWeight: FontWeight.w600),
      ),
    );
  }
}

// ── ⑧ 새 준비물 카드 (clothes / supplies 텍스트 직접 표시) ────────────────
class _BriefingPrepCard extends StatelessWidget {
  final BriefingWeatherModel weather;
  const _BriefingPrepCard({required this.weather});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.backpack_outlined, color: AppColors.primary),
                const SizedBox(width: 8),
                const Text('오늘의 준비물',
                    style: TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w700)),
              ],
            ),
            const SizedBox(height: 16),
            // 옷차림 추천
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.dry_cleaning_outlined,
                    size: 20, color: AppColors.secondary),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('옷차림 추천',
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textSecondary)),
                      const SizedBox(height: 4),
                      Text(weather.clothes,
                          style: const TextStyle(fontSize: 14)),
                    ],
                  ),
                ),
              ],
            ),
            if (weather.supplies.isNotEmpty) ...[
              const SizedBox(height: 12),
              const Divider(),
              const SizedBox(height: 12),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.checklist_outlined,
                      size: 20, color: AppColors.secondary),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('챙겨야 할 것',
                            style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: AppColors.textSecondary)),
                        const SizedBox(height: 4),
                        Text(weather.supplies,
                            style: const TextStyle(fontSize: 14)),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ── ③ 교통 이슈 카드 ──────────────────────────────
class _TrafficIssueCard extends StatelessWidget {
  final List<IssueModel> issues;
  const _TrafficIssueCard({required this.issues});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(
                  Icons.warning_amber_outlined,
                  color: AppColors.warning,
                ),
                const SizedBox(width: 8),
                const Text(
                  '주요 교통 이슈',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: issues.isEmpty
                        ? Colors.green.withValues(alpha: 0.1)
                        : AppColors.warning.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    issues.isEmpty ? '이상 없음' : '${issues.length}건',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: issues.isEmpty ? Colors.green : AppColors.warning,
                    ),
                  ),
                ),
              ],
            ),
            if (issues.isEmpty) ...[
              const SizedBox(height: 12),
              const Text(
                '현재 주요 교통 이슈가 없어요.',
                style: TextStyle(fontSize: 14, color: AppColors.textSecondary),
              ),
            ] else ...[
              const SizedBox(height: 12),
              ...issues.map(
                (issue) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: const EdgeInsets.only(top: 5),
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: issue.isFullClosure
                              ? AppColors.error
                              : AppColors.warning,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              issue.location,
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              issue.description,
                              style: const TextStyle(
                                fontSize: 13,
                                color: AppColors.textSecondary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ── ③ 오늘의 일정 카드 ───────────────────────────
class _ScheduleCard extends StatelessWidget {
  final List<BriefingCalendarGroup> calendarGroups;
  final String? calendarError;
  const _ScheduleCard({required this.calendarGroups, this.calendarError});

  @override
  Widget build(BuildContext context) {
    // 모든 그룹의 이벤트를 시간순으로 병합
    final allEvents = calendarGroups
        .expand((g) => g.items.map((e) => (group: g, event: e)))
        .toList()
      ..sort((a, b) => a.event.sortKey.compareTo(b.event.sortKey));

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(
                  Icons.calendar_today_outlined,
                  color: AppColors.primary,
                  size: 20,
                ),
                const SizedBox(width: 8),
                const Text(
                  '오늘의 일정',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.green.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.green.withValues(alpha: 0.3),
                    ),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.check_circle_outline,
                        size: 12,
                        color: Colors.green,
                      ),
                      SizedBox(width: 4),
                      Text(
                        'Google Calendar 연동됨',
                        style: TextStyle(
                          fontSize: 11,
                          color: Colors.green,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            if (calendarError != null)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.error_outline, color: Colors.red, size: 16),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '캘린더를 불러오지 못했어요.\n$calendarError',
                        style: const TextStyle(fontSize: 13, color: Colors.red),
                      ),
                    ),
                  ],
                ),
              )
            else if (allEvents.isEmpty)
              const Text(
                '오늘 일정이 없어요.',
                style: TextStyle(fontSize: 14, color: AppColors.textSecondary),
              )
            else
              ...allEvents.asMap().entries.map((entry) {
                final i = entry.key;
                final item = entry.value;
                return Column(
                  children: [
                    if (i > 0) const Divider(height: 16),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: 44,
                          child: Text(
                            item.event.startTimeLabel,
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: AppColors.primary,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item.event.summary,
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Row(
                                children: [
                                  const Icon(Icons.calendar_month_outlined,
                                      size: 11,
                                      color: AppColors.textSecondary),
                                  const SizedBox(width: 3),
                                  Expanded(
                                    child: Text(
                                      item.group.summary,
                                      style: const TextStyle(
                                          fontSize: 11,
                                          color: AppColors.textSecondary),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                              if (item.event.location != null &&
                                  item.event.location!.isNotEmpty) ...[
                                const SizedBox(height: 2),
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.place_outlined,
                                      size: 12,
                                      color: AppColors.textSecondary,
                                    ),
                                    const SizedBox(width: 2),
                                    Expanded(
                                      child: Text(
                                        item.event.location!,
                                        style: const TextStyle(
                                          fontSize: 12,
                                          color: AppColors.textSecondary,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                              if (item.event.description != null &&
                                  item.event.description!.isNotEmpty) ...[
                                const SizedBox(height: 2),
                                Text(
                                  item.event.description!,
                                  style: const TextStyle(
                                      fontSize: 12,
                                      color: AppColors.textSecondary),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                );
              }),
          ],
        ),
      ),
    );
  }
}

// ── ④ 미팅 경로 카드 ──────────────────────────────
class _MeetingRouteCard extends StatelessWidget {
  final RouteModel route;
  const _MeetingRouteCard({required this.route});

  Color _lineColor(String? subwayCode) {
    return switch (subwayCode) {
      '1' => Colors.blue,
      '2' => Colors.green,
      '3' => Colors.orange,
      '4' => Colors.lightBlue,
      '5' => Colors.purple,
      '6' => Colors.brown,
      '7' => Colors.green.shade800,
      '8' => Colors.pink,
      '9' => Colors.yellow.shade800,
      _ => AppColors.primary,
    };
  }

  @override
  Widget build(BuildContext context) {
    final transitPaths = route.path.where((p) => !p.isWalking).toList();

    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.08),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.directions_transit_outlined,
                  color: AppColors.primary,
                  size: 18,
                ),
                const SizedBox(width: 8),
                const Text(
                  '오늘 미팅 경로',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppColors.primary,
                  ),
                ),
                const Spacer(),
                Text(
                  '총 ${route.totalTime}분',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppColors.primary,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 경로 요약 칩
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: route.path.map((p) {
                    if (p.isWalking) {
                      return Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.border,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.directions_walk,
                              size: 13,
                              color: AppColors.textSecondary,
                            ),
                            const SizedBox(width: 3),
                            Text(
                              '${p.sectionTime}분',
                              style: const TextStyle(
                                fontSize: 12,
                                color: AppColors.textSecondary,
                              ),
                            ),
                          ],
                        ),
                      );
                    }
                    final color = p.isSubway
                        ? _lineColor(p.no.isNotEmpty ? p.no.first : null)
                        : Colors.green;
                    if (p.isSubway) {
                      // 지하철: subwayLineName 사용 (호선 중복 방어)
                      return Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: color.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: color,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Text(
                              p.subwayLineName,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: color,
                              ),
                            ),
                          ],
                        ),
                      );
                    } else {
                      // 버스: no 전체를 강챔 치프로 표시
                      return Wrap(
                        spacing: 4,
                        runSpacing: 2,
                        children: p.no
                            .where((n) => n.isNotEmpty)
                            .map(
                              (n) => Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: color.withValues(alpha: 0.12),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      width: 8,
                                      height: 8,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: color,
                                      ),
                                    ),
                                    const SizedBox(width: 4),
                                    Text(
                                      '${n}번',
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w600,
                                        color: color,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            )
                            .toList(),
                      );
                    }
                  }).toList(),
                ),
                const SizedBox(height: 12),
                // 출발-도착 정보
                if (transitPaths.isNotEmpty)
                  Row(
                    children: [
                      Text(
                        route.startName ?? route.path.first.start ?? '출발',
                        style: const TextStyle(
                          fontSize: 13,
                          color: AppColors.textSecondary,
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 6),
                        child: Icon(
                          Icons.arrow_forward,
                          size: 14,
                          color: AppColors.textSecondary,
                        ),
                      ),
                      Text(
                        route.endName ?? route.path.last.end ?? '도착',
                        style: const TextStyle(
                          fontSize: 13,
                          color: AppColors.textSecondary,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        '${(route.payment).toString().replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}원',
                        style: const TextStyle(
                          fontSize: 13,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () {},
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primary,
                      side: const BorderSide(color: AppColors.primary),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                    child: const Text(
                      '경로 보기',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── fallback 날씨 카드 (WeatherAirQualityModel 기반) ──────────────────────────
class _WeatherCard extends StatelessWidget {
  final WeatherAirQualityModel weather;
  const _WeatherCard({required this.weather});

  @override
  Widget build(BuildContext context) {
    final current = weather.current;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.wb_sunny_outlined, color: AppColors.primary),
                const SizedBox(width: 8),
                const Text('오늘의 날씨',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(weather.skyEmoji, style: const TextStyle(fontSize: 40)),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${current?.tmp ?? '--'}°',
                        style: const TextStyle(
                            fontSize: 32, fontWeight: FontWeight.w700)),
                    Text(
                      current != null
                          ? '강수확률 ${current.pop}%  습도 ${current.reh}%'
                          : '',
                      style: const TextStyle(
                          fontSize: 13, color: AppColors.textSecondary),
                    ),
                  ],
                ),
                const Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text('PM10 ${weather.pm10Label}',
                        style: const TextStyle(
                            fontSize: 13, color: AppColors.textSecondary)),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ── fallback 준비물 카드 (WeatherAirQualityModel 기반) ────────────────────────
class _PrepCard extends StatelessWidget {
  final WeatherAirQualityModel weather;
  const _PrepCard({required this.weather});

  String get _clothesRecommendation {
    final tmp = weather.current?.tmp ?? 20;
    if (tmp >= 28) return '민소매, 반팔, 반바지, 원피스';
    if (tmp >= 23) return '반팔, 얇은 셔츠, 면바지, 반바지';
    if (tmp >= 20) return '블라우스, 얇은 가디건, 면바지';
    if (tmp >= 17) return '얇은 가디건, 긴바지';
    if (tmp >= 12) return '자켓, 가디건, 청바지';
    if (tmp >= 9)  return '트렌치코트, 니트, 청바지';
    if (tmp >= 5)  return '울코트, 히트텍, 니트';
    return '패딩, 두꺼운 코트, 목도리';
  }

  String get _suppliesRecommendation {
    final pop = weather.current?.pop ?? 0;
    final pm10 = weather.pm10Label;
    final items = <String>[];
    if (pop >= 60) items.add('우산');
    if (pm10 == '나쁨' || pm10 == '매우나쁨') items.add('마스크');
    return items.isEmpty ? '특별히 챙길 것이 없어요.' : items.join(', ');
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.backpack_outlined, color: AppColors.primary),
                const SizedBox(width: 8),
                const Text('오늘의 준비물',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.dry_cleaning_outlined,
                    size: 20, color: AppColors.secondary),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('옷차림 추천',
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textSecondary)),
                      const SizedBox(height: 4),
                      Text(_clothesRecommendation,
                          style: const TextStyle(fontSize: 14)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Divider(),
            const SizedBox(height: 12),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.checklist_outlined,
                    size: 20, color: AppColors.secondary),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('챙겨야 할 것',
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textSecondary)),
                      const SizedBox(height: 4),
                      Text(_suppliesRecommendation,
                          style: const TextStyle(fontSize: 14)),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ── ⑥ AI 요약 카드 ────────────────────────────────
class _AiSummaryCard extends StatelessWidget {
  final AiSummaryModel? summary;
  const _AiSummaryCard({required this.summary});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.secondary, Color(0xFF00D4C0)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: const Row(
              children: [
                Icon(Icons.auto_awesome, color: Colors.white, size: 18),
                SizedBox(width: 8),
                Text(
                  'AI 요약',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: summary == null
                ? const Text(
                    '루틴을 등록하면 AI가 맞춤 브리핑을 제공해드려요.',
                    style: TextStyle(
                      fontSize: 14,
                      color: AppColors.textSecondary,
                    ),
                  )
                : Text(
                    summary!.summary,
                    style: const TextStyle(fontSize: 14, height: 1.6),
                  ),
          ),
        ],
      ),
    );
  }
}