// GET /me/routines/active/route  &  /me/routes/active/reco 응답

// type: "walk" | "bus" | "subway"  (백엔드 RouteSectionDto.type)

/// 단일 구간 — walk / bus / subway 공통
class PathModel {
  final String type;         // "walk" | "bus" | "subway"
  final int sectionTime;     // 분
  final List<String> no;     // 버스 번호 or 지하철 노선 번호 목록
  final String? start;       // 승차 정류장/역
  final String? end;         // 하차 정류장/역
  final int? stationCount;
  final List<String> stationName; // 경유 정류장/역 목록
  final String? way;         // 지하철 방향 (SubwaySectionDto.way)

  const PathModel({
    required this.type,
    required this.sectionTime,
    this.no = const [],
    this.start,
    this.end,
    this.stationCount,
    this.stationName = const [],
    this.way,
  });

  bool get isWalking => type == 'walk';
  bool get isSubway  => type == 'subway';
  bool get isBus     => type == 'bus';

  /// 화면에 표시할 정거장 수.
  /// stationCount(백엔드 값)가 있으면 우선 사용하고,
  /// 없으면 stationName 목록 길이에서 1을 뺀 값 사용
  /// (stationName에 start/end가 포함되어 있어 -1 처리).
  int get displayStationCount {
    if (stationCount != null && stationCount! > 0) return stationCount!;
    return (stationName.length - 1).clamp(0, 9999);
  }

  String get stationCountLabel => '${displayStationCount}정거장';

  String get typeLabel {
    if (isWalking) return '도보';
    if (isSubway)  return '지하철';
    return '버스';
  }

  /// 지하철 노선 번호(no)를 사람이 읽을 수 있는 이름으로 변환
  /// 백엔드가 내부 코드번호로 내려보낼 때 보정
  static const _subwayLineNames = <String, String>{
    '1': '1호선',
    '2': '2호선',
    '3': '3호선',
    '4': '4호선',
    '5': '5호선',
    '6': '6호선',
    '7': '7호선',
    '8': '8호선',
    '9': '9호선',
    '21': '인천1호선',
    '22': '인천2호선',
    '100': '경의중앙선',
    '101': '공항철도',
    '102': '자기부상',
    '103': '경춘선',
    '104': '수인분당선',
    '105': '신분당선',
    '106': '의정부경전철',
    '107': '에버라인',
    '108': '경강선',
    '109': '신분당선',   // 일부 API가 신분당선을 109로 반환
    '110': '우이신설선',
    '111': '서해선',
    '112': '김포골드라인',
    '113': '수도권9호선',
    '114': '신림선',
  };

  /// 지하철일 때 표시할 노선명 (예: "2호선", "신분당선")
  String get subwayLineName {
    if (!isSubway || no.isEmpty) return '지하철';
    final lineNo = no.first;
    return _subwayLineNames[lineNo] ?? '${lineNo}호선';
  }

  factory PathModel.fromJson(Map<String, dynamic> json) => PathModel(
        type:         (json['type']        as String?) ?? 'walk',
        sectionTime:  (json['sectionTime'] as num?)?.toInt() ?? 0,
        no:           (json['no'] as List<dynamic>?)?.cast<String>() ?? const [],
        start:        json['start']        as String?,
        end:          json['end']          as String?,
        stationCount: (json['stationCount'] as num?)?.toInt(),
        stationName:  (json['stationName'] as List<dynamic>?)?.cast<String>() ?? const [],
        way:          json['way']          as String?,
      );

  Map<String, dynamic> toJson() => {
        'type':         type,
        'sectionTime':  sectionTime,
        'no':           no,
        'start':        start,
        'end':          end,
        'stationCount': stationCount,
        'stationName':  stationName,
        'way':          way,
      };
}

/// GET /me/routines/active/route  &  /me/routes/active/reco 응답 (RouteDto)
class RouteModel {
  final int recoId;
  final int totalDistance; // 미터
  final int totalTime;     // 분
  final int payment;       // 원
  final String? startName;
  final String? endName;
  final List<PathModel> path;

  const RouteModel({
    required this.recoId,
    required this.totalDistance,
    required this.totalTime,
    required this.payment,
    this.startName,
    this.endName,
    required this.path,
  });

  factory RouteModel.fromJson(Map<String, dynamic> json) {
    // searchRoutes 응답(RouteListDto): path 대신 trafficType 배열로 내려옴
    // e.g. { "recoId": 1, "totalTime": 45, "payment": 1650,
    //        "trafficType": ["walk", "bus:360", "subway:2", "walk"] }
    if (json['trafficType'] is List) {
      return RouteModel._fromListDto(json);
    }

    return RouteModel(
      recoId:        (json['recoId'] as num?)?.toInt() ?? 0,
      totalDistance: (json['totalDistance'] as num?)?.toInt() ?? 0,
      totalTime:     (json['totalTime']     as num).toInt(),
      payment:       (json['payment']       as num).toInt(),
      startName:     json['startName']      as String?,
      endName:       json['endName']        as String?,
      path: (json['path'] as List<dynamic>?)
              ?.map((e) => PathModel.fromJson(e as Map<String, dynamic>))
              .toList() ??
          const [],
    );
  }

  /// searchRoutes 응답 — trafficType 배열로 경로 구성
  factory RouteModel._fromListDto(Map<String, dynamic> json) {
    final types = (json['trafficType'] as List<dynamic>).cast<String>();
    return RouteModel(
      recoId:        (json['recoId'] as num?)?.toInt() ?? 0,
      totalDistance: 0,
      totalTime:     (json['totalTime'] as num).toInt(),
      payment:       (json['payment']   as num).toInt(),
      path:          types.map(_pathFromType).toList(),
    );
  }

  static PathModel _pathFromType(String type) {
    if (type == 'walk') {
      return const PathModel(type: 'walk', sectionTime: 0);
    }
    if (type.startsWith('bus:')) {
      return PathModel(
        type: 'bus',
        sectionTime: 0,
        no: [type.substring(4)],
      );
    }
    if (type.startsWith('subway:')) {
      return PathModel(
        type: 'subway',
        sectionTime: 0,
        no: [type.substring(7)],
      );
    }
    return const PathModel(type: 'walk', sectionTime: 0);
  }

  Map<String, dynamic> toJson() => {
        'recoId':        recoId,
        'totalDistance': totalDistance,
        'totalTime':     totalTime,
        'payment':       payment,
        'startName':     startName,
        'endName':       endName,
        'path':          path.map((e) => e.toJson()).toList(),
      };
}

// GET /me/routines/active/status 응답 (CurrentLocationDto)
class LiveStatusModel {
  final String status;   // "대기중" | "도보중" | "탑승중"
  final int updatedAt;   // Unix timestamp millis (Long)

  const LiveStatusModel({required this.status, required this.updatedAt});

  factory LiveStatusModel.fromJson(Map<String, dynamic> json) =>
      LiveStatusModel(
        status:    json['status']    as String,
        updatedAt: (json['updatedAt'] as num).toInt(),
      );
}

// GET /me/routines/active/route  &  /me/routines/active/reco 응답 (LiveRouteDto)
class LiveRouteModel {
  final int totalDistance;
  final int totalTime;
  final int payment;
  final String? startName;
  final String? endName;
  final List<PathModel> path;

  const LiveRouteModel({
    required this.totalDistance,
    required this.totalTime,
    required this.payment,
    this.startName,
    this.endName,
    required this.path,
  });

  factory LiveRouteModel.fromJson(Map<String, dynamic> json) => LiveRouteModel(
        totalDistance: (json['totalDistance'] as num?)?.toInt() ?? 0,
        totalTime:     (json['totalTime']     as num).toInt(),
        payment:       (json['payment']       as num).toInt(),
        startName:     json['startName']      as String?,
        endName:       json['endName']        as String?,
        path: (json['path'] as List<dynamic>?)
                ?.map((e) => PathModel.fromJson(e as Map<String, dynamic>))
                .toList() ??
            const [],
      );

  Map<String, dynamic> toJson() => {
        'totalDistance': totalDistance,
        'totalTime':     totalTime,
        'payment':       payment,
        'startName':     startName,
        'endName':       endName,
        'path':          path.map((e) => e.toJson()).toList(),
      };
}

// GET /me/routines/active/location 응답 — RouteXYDto 단일 좌표 포인트
class RouteXYModel {
  final String? stationName; // 정류장/역 이름 (null이면 도보 구간)
  final double? x;           // 경도 (longitude)
  final double? y;           // 위도 (latitude)
  final String? arsID;       // 버스 정류장 ID
  final String? type;        // "walk" | "bus" | "subway"

  const RouteXYModel({this.stationName, this.x, this.y, this.arsID, this.type});

  bool get hasCoord => x != null && y != null;

  factory RouteXYModel.fromJson(Map<String, dynamic> json) => RouteXYModel(
        stationName: json['stationName'] as String?,
        x:           (json['x'] as num?)?.toDouble(),
        y:           (json['y'] as num?)?.toDouble(),
        arsID:       json['arsID'] as String?,
        type:        json['type'] as String?,
      );
}

// GET /me/routines/active/location 응답 (CurrentSectionDto)
class CurrentSectionModel {
  final int idx;              // 현재 위치 구간 인덱스 (0-based)
  final List<String> section; // 전체 구간 타입 목록 ("walk" | "bus" | "subway")
  final List<RouteXYModel> xy; // 전체 경로 좌표 포인트 목록

  const CurrentSectionModel({
    required this.idx,
    required this.section,
    this.xy = const [],
  });

  factory CurrentSectionModel.fromJson(Map<String, dynamic> json) =>
      CurrentSectionModel(
        idx:     (json['idx'] as num).toInt(),
        section: (json['section'] as List<dynamic>).cast<String>(),
        xy: (json['xy'] as List<dynamic>?)
                ?.map((e) => RouteXYModel.fromJson(e as Map<String, dynamic>))
                .toList() ??
            const [],
      );
}

// GET /me/issues 응답 항목
class IssueModel {
  final String location;
  final String description;
  final String startDateTime;
  final String endDateTime;
  final bool isFullClosure;

  const IssueModel({
    required this.location,
    required this.description,
    required this.startDateTime,
    required this.endDateTime,
    required this.isFullClosure,
  });

  factory IssueModel.fromJson(Map<String, dynamic> json) => IssueModel(
        location:      json['location']      as String,
        description:   json['description']   as String,
        startDateTime: json['startDateTime'] as String,
        endDateTime:   json['endDateTime']   as String,
        isFullClosure: json['isFullClosure'] as bool,
      );
}