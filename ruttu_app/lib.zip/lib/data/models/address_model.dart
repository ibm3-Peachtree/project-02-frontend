// GET /address, POST /address 응답
class AddressModel {
  final int addressId;
  final String name;          // 별칭 (예: "집", "회사")
  final String roadAddress;   // 도로명주소
  final String jibunAddress;  // 지번주소
  final double? latitude;
  final double? longitude;

  const AddressModel({
    required this.addressId,
    required this.name,
    required this.roadAddress,
    this.jibunAddress = '',
    this.latitude,
    this.longitude,
  });

  /// 호환용: address 게터 (roadAddress 반환)
  String get address => roadAddress;

  factory AddressModel.fromJson(Map<String, dynamic> json) => AddressModel(
        addressId:    json['addressId']    as int,
        name:         json['name']         as String,
        roadAddress:  (json['roadAddress'] ?? json['address'] ?? '') as String,
        jibunAddress: (json['jibunAddress'] ?? '') as String,
        latitude:     (json['latitude']  as num?)?.toDouble(),
        longitude:    (json['longitude'] as num?)?.toDouble(),
      );

  Map<String, dynamic> toJson() => {
        'addressId':    addressId,
        'name':         name,
        'roadAddress':  roadAddress,
        'jibunAddress': jibunAddress,
        if (latitude  != null) 'latitude':  latitude,
        if (longitude != null) 'longitude': longitude,
      };
}